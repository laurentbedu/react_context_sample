import React, { createContext, useState } from 'react';

export const ThemeContext = createContext();

const ThemeContextProvider = (props) => {
    
	const [isDark, setIsDark] = useState(false);

	const toggleTheme = () => {
		setIsDark(!isDark);
	}
	const { children } = props;
	return (
		<ThemeContext.Provider value={{ isDark, toggleTheme }}>
 			{children}
		</ThemeContext.Provider>
	)
}

export default ThemeContextProvider;